<?php
$SES = array (
  '11e87f879786b26df426df0e61283dc2' => 
  array (
    'cfg' => 
    array (
      'charsets' => 'cp1251 utf8 latin1',
      'lang' => 'en',
      'time_web' => '30',
      'time_cron' => '600',
      'backup_path' => 'backup/',
      'backup_url' => 'backup/',
      'only_create' => 'MRG_MyISAM MERGE HEAP MEMORY',
      'globstat' => 0,
      'my_host' => 'localhost',
      'my_port' => 3306,
      'my_user' => 'fvncom_qhung',
      'my_pass' => 'd=P.;PR[AZv2',
      'my_comp' => 0,
      'my_db' => '',
      'auth' => 'mysql cfg',
      'user' => '',
      'pass' => '',
      'confirm' => '6',
      'exitURL' => './',
    ),
    'time' => 1357092992,
    'lng' => 'en',
  ),
);
?>